﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace org.wikipedia.www
{
    public class ArticleInfo
    {
        public String Url { get; internal set; }
        public String Title { get; internal set; }
        public String Introduction { get; internal set; }

        public String ArticleHtml { get; internal set; }

        private String articleText = String.Empty;
        private Boolean isProcessed = false;
        public String ArticleText 
        {
            get
            {
                if (!this.isProcessed)
                    this.articleText = xsd.XSDConvert.ConvertToHtml(this.articleText);
                isProcessed = true;
                return this.articleText;
            }

            internal set { this.articleText = value; }
        }
    }
}
